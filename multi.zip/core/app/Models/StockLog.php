<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StockLog extends Model
{
    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function batch() { return $this->belongsTo(ProductBatch::class); }

    public function productVariant()
    {
        return $this->belongsTo(ProductVariant::class);
    }

    public function order()
    {
        return $this->belongsTo(Order::class);
    }
}
