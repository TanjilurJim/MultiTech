<ul class="list list--row mobile-menu-icons justify-content-center justify-content-md-end option-list d-lg-none d-flex">
    <li>
        <a href="<?php echo e(route('categories')); ?>" class="ecommerce" id="cate-button">
            <span class="ecommerce__icon">
                <img src="<?php echo e(svg('category')); ?>" alt="">
            </span>
            <span class="ecommerce__text"><?php echo app('translator')->get('Category'); ?></span>
        </a>
    </li>

    <?php if(gs('product_wishlist')): ?>
        <li>
            <a href="javascript:void(0)" class="ecommerce wish-button">
                <span class="ecommerce__icon">
                    <img src="<?php echo e(svg('wishlist')); ?>" alt="">
                    <span class="ecommerce__is wishlist-count d-none"></span>
                </span>
                <span class="ecommerce__text"><?php echo app('translator')->get('Wishlist'); ?></span>
            </a>
        </li>
    <?php endif; ?>

    <?php if(gs('product_compare')): ?>
        <li>
            <a href="<?php echo e(route('compare.all')); ?>" class="ecommerce">
                <span class="ecommerce__icon">
                    <img src="<?php echo e(svg('compare')); ?>" alt="">
                    <span class="ecommerce__is compare-count d-none"></span>
                </span>
                <span class="ecommerce__text"><?php echo app('translator')->get('Compare'); ?></span>
            </a>
        </li>
    <?php endif; ?>

    <li>
        <a href="javascript:void(0)" class="ecommerce <?php if(auth()->guard()->check()): ?> user-account-btn <?php endif; ?>" id="account-button" <?php if(auth()->guard()->guest()): ?> data-bs-toggle="modal" data-bs-target="#loginModal" <?php endif; ?>>
            <span class="ecommerce__icon">
                <img src="<?php echo e(svg('my_account')); ?>" alt="">
            </span>
            <span class="ecommerce__text"><?php echo app('translator')->get('My Account'); ?></span>
        </a>
    </li>
</ul>


<div class="site-sidebar mobile-menu sidebar-nav d-lg-none">
    <button type="button" class="sidebar-close-btn">
        <i class="las la-times"></i>
    </button>

    <div class="mobile-menu-header">
        <div class="d-block d-lg-none">
            <?php echo $__env->make('Template::partials.menu.language_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <div class="mobile-menu-body">
        <?php echo $__env->make('Template::partials.menu.site_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php /**PATH C:\laragon\www\unisales\core\resources\views/templates/basic/partials/mobile_menu.blade.php ENDPATH**/ ?>