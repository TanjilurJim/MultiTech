<?php if(gs('multi_language')): ?>
    <?php
        $language = App\Models\Language::all();
        $activeLanguage = $language->where('code', session('lang'))->first();
    ?>
    <div class="dropdown dropdown--lang">
        <button class="dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
            <img class="dropdown-flag lazyload"
                src="<?php echo e(getImage(getFilePath('language') . '/' . @$activeLanguage->image, getFileSize('language'))); ?>"
                alt="<?php echo app('translator')->get('image'); ?>">
            <span><?php echo e(__($activeLanguage['name'])); ?></span>
        </button>

        <div class="dropdown-menu">
            <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="dropdown-item" href="<?php echo e(route('lang', $lang->code)); ?>">
                    <img class="dropdown-flag lazyload"
                        src="<?php echo e(getImage(getFilePath('language') . '/' . @$lang->image, getFileSize('language'))); ?>"
                        alt="country">
                    <span><?php echo e(__(@$lang->name)); ?></span>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\unisales\core\resources\views/templates/basic/partials/menu/language_menu.blade.php ENDPATH**/ ?>