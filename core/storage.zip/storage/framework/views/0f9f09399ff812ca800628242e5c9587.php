<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['id', 'images' => [], 'for', 'isSingle' => 0, 'inputName' => $inputName]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['id', 'images' => [], 'for', 'isSingle' => 0, 'inputName' => $inputName]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<div class="gallery-wrapper <?php if($isSingle): ?> single-image <?php endif; ?>">
    <?php
        if ($isSingle) {
            $value = $images->id ?? '';
        } else {
            $value = implode(',', @$images->pluck('id')->toArray());
        }
    ?>

    <div class="gallery-images" id="<?php echo e($id); ?>">
        <?php if($isSingle && $images): ?>
            <?php if (isset($component)) { $__componentOriginaldd756b93b6faadd630b609c71504e73f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldd756b93b6faadd630b609c71504e73f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.media-uploader-gallery-item','data' => ['image' => $images]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('media-uploader-gallery-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($images)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldd756b93b6faadd630b609c71504e73f)): ?>
<?php $attributes = $__attributesOriginaldd756b93b6faadd630b609c71504e73f; ?>
<?php unset($__attributesOriginaldd756b93b6faadd630b609c71504e73f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldd756b93b6faadd630b609c71504e73f)): ?>
<?php $component = $__componentOriginaldd756b93b6faadd630b609c71504e73f; ?>
<?php unset($__componentOriginaldd756b93b6faadd630b609c71504e73f); ?>
<?php endif; ?>
        <?php else: ?>
            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galleryImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginaldd756b93b6faadd630b609c71504e73f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldd756b93b6faadd630b609c71504e73f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.media-uploader-gallery-item','data' => ['image' => $galleryImage]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('media-uploader-gallery-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($galleryImage)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldd756b93b6faadd630b609c71504e73f)): ?>
<?php $attributes = $__attributesOriginaldd756b93b6faadd630b609c71504e73f; ?>
<?php unset($__attributesOriginaldd756b93b6faadd630b609c71504e73f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldd756b93b6faadd630b609c71504e73f)): ?>
<?php $component = $__componentOriginaldd756b93b6faadd630b609c71504e73f; ?>
<?php unset($__componentOriginaldd756b93b6faadd630b609c71504e73f); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <?php if(!$isSingle): ?>
            <button type="button" class="mediaUploaderBtn multiple" data-preview_element_id="<?php echo e($id); ?>" data-files_for="<?php echo e($for); ?>" data-input_field_name="<?php echo e($inputName); ?>">
                <i class="la la-plus"></i> <br> <?php echo app('translator')->get('Upload'); ?>
            </button>
        <?php endif; ?>
    </div>

    <?php if($isSingle): ?>
        <button type="button" class="btn btn--dark mediaUploaderBtn" data-single_file="1" data-preview_element_id="<?php echo e($id); ?>" data-files_for="<?php echo e($for); ?>" data-input_field_name="<?php echo e($inputName); ?>"><i class="la la-pencil m-0"></i></button>
    <?php endif; ?>

    <input type="hidden" name="<?php echo e($inputName); ?>" value="<?php echo e($value); ?>">
</div>


<?php if (! $__env->hasRenderedOnce('8922e289-3a49-459f-aa69-4d96f0ada4d1')): $__env->markAsRenderedOnce('8922e289-3a49-459f-aa69-4d96f0ada4d1');
$__env->startPush('style'); ?>
    <style>
        .gallery-wrapper {
            border: 1px dashed #ebebeb;
            padding: 1rem;
            border-radius: 8px;
        }

        .gallery-wrapper.single-image {
            width: 200px;
            height: 200px;
            position: relative;
            padding: 1px;
            background: url('<?php echo e(getImage(null)); ?>');
            background-size: cover;
        }

        .gallery-wrapper.single-image .mediaUploaderBtn {
            position: absolute;
            bottom: -6px;
            right: -6px;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .gallery-wrapper.single-image .gallery-item {
            border: 0;
        }

        .gallery-images {
            display: grid;
            gap: 1rem;
            grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
            height: 100%;
        }

        .gallery-item {
            border: 1px solid #ebebeb;
            border-radius: 5px;
            overflow: hidden;
            position: relative;
            aspect-ratio: 1 / 1;
        }

        .gallery-item-remove {
            position: absolute;
            right: 5px;
            top: 5px;
            background-color: #f7f7f7;
            color: #a0a0a0;
            border-radius: 50%;
            justify-content: center;
            align-items: center;
            height: 24px;
            width: 24px;
            font-size: 0.875rem;
            display: none;
        }

        .gallery-item:hover .gallery-item-remove {
            display: flex;
        }

        .gallery-item-remove:hover {
            background-color: #e7e7e7;
            transition: all 0.3ms ease-in-out;
        }
    </style>
<?php $__env->stopPush(); endif; ?>
<?php /**PATH C:\laragon\www\unisales\core\resources\views/components/media-uploader-input.blade.php ENDPATH**/ ?>