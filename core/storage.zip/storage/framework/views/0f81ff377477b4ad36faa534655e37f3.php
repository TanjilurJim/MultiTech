 <div class="nav--links">
     <?php
         $menus = $headerOne->links ?? [];
     ?>
     <?php if($menus): ?>
         <ul>
             <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <li><a href="<?php echo e(url($menu->url)); ?>"><?php echo e(__($menu->name)); ?></a></li>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </ul>
     <?php endif; ?>
 </div>
<?php /**PATH C:\laragon\www\unisales\core\resources\views/templates/basic/partials/header_top_links.blade.php ENDPATH**/ ?>