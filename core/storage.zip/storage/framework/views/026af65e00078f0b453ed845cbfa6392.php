<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'isDigital' => false,
    'quantity' => 1,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'isDigital' => false,
    'quantity' => 1,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div <?php echo e($attributes->merge(['class' => 'product-quantity-input d-flex quantity'])); ?>>
    <button class="qtyButton minus" <?php if($isDigital || $quantity == 1): echo 'disabled'; endif; ?>><i class="la la-minus"></i></button>
    <input type="number" type="number" min="1" name="quantity" step="1" value="<?php echo e($quantity); ?>" <?php if($isDigital): echo 'readonly'; endif; ?> autocomplete="off">
    <button type="button" class="qtyButton plus" <?php if($isDigital): echo 'disabled'; endif; ?>><i class="la la-plus"></i></button>
</div>
<?php /**PATH C:\laragon\www\unisales\core\resources\views/components/frontend/quantity-input.blade.php ENDPATH**/ ?>