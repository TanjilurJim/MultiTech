<?php $__env->startSection('app'); ?>
    <?php
        $loginContent = getContent('login_page.content', true);
    ?>
    <div class="container">
        <div class="row g-4 gy-lg-0 <?php if($loginContent->data_values->image): ?> justify-content-between <?php else: ?> justify-content-center <?php endif; ?> flex-wrap-reverse align-items-center">
            <?php if($loginContent->data_values->image): ?>
                <div class="col-lg-6 col-xxl-7 d-none d-lg-block">
                    <div class="text-center pe-xl-5">
                        <img src="<?php echo e(frontendImage('login_page', @$loginContent->data_values->image, '600x840')); ?>" alt="image" class="img-fluid">
                    </div>
                </div>
            <?php endif; ?>

            <div class="<?php if($loginContent->data_values->image): ?> col-lg-6 col-xxl-5 <?php else: ?> col-xl-5 col-lg-7 col-md-9 <?php endif; ?>">
                <div class="auth-form">
                    <div class="auth-form__head text-center">
                        <div class="logo">
                            <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(siteLogo('dark')); ?>" alt="<?php echo app('translator')->get('logo'); ?>"></a>
                        </div>

                    </div>
                    <div class="auth-form__body">
                        <form method="POST" action="<?php echo e(route('user.login')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label class="form--label"><?php echo app('translator')->get('Username'); ?></label>
                                <input class="form--control" type="text" name="username" value="<?php echo e(old('username')); ?>" placeholder="<?php echo app('translator')->get('Username'); ?>" required autofocus>
                            </div>
                            <div class="form-group">
                                <label class="form--label" for="password"><?php echo app('translator')->get('Password'); ?></label>
                                <input id="password" type="password" name="password" class="form--control" placeholder="<?php echo app('translator')->get('Enter Your Password'); ?>" required autocomplete="current-password">
                            </div>

                            <div class="form-group">
                                <div class="d-flex gap-1 flex-wrap justify-content-between">
                                    <div class="form-check form--check">
                                        <input class="form-check-input" type="checkbox" name="remember" id="remember">
                                        <label class="form-check-label" for="remember">
                                            <?php echo app('translator')->get('Remember Me'); ?>
                                        </label>
                                    </div>

                                    <a href="<?php echo e(route('user.password.request')); ?>" class="t-link d-block text-end text--base heading-clr sm-text fw-md">
                                        <?php echo app('translator')->get('Forgot Password?'); ?>
                                    </a>
                                </div>
                            </div>

                            <?php if (isset($component)) { $__componentOriginalff0a9fdc5428085522b49c68070c11d6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff0a9fdc5428085522b49c68070c11d6 = $attributes; } ?>
<?php $component = App\View\Components\Captcha::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('captcha'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Captcha::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff0a9fdc5428085522b49c68070c11d6)): ?>
<?php $attributes = $__attributesOriginalff0a9fdc5428085522b49c68070c11d6; ?>
<?php unset($__attributesOriginalff0a9fdc5428085522b49c68070c11d6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff0a9fdc5428085522b49c68070c11d6)): ?>
<?php $component = $__componentOriginalff0a9fdc5428085522b49c68070c11d6; ?>
<?php unset($__componentOriginalff0a9fdc5428085522b49c68070c11d6); ?>
<?php endif; ?>

                            <button class="btn btn--md btn--base sm-text h-45 w-100" type="submit" id="recaptcha"><?php echo app('translator')->get('Login Account'); ?></button>

                            <?php if(Route::has('user.register')): ?>
                                <p class="mt-2 mb-0">
                                    <?php echo app('translator')->get('Don\'t have an account'); ?> ? <a href="<?php echo e(route('user.register')); ?>" class="t-link t-link--base text--base"><?php echo app('translator')->get('Create An Account'); ?></a>
                                </p>
                            <?php endif; ?>
                        </form>
                        <?php echo $__env->make('Template::partials.social_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Template::layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\unisales\core\resources\views/templates/basic/user/auth/login.blade.php ENDPATH**/ ?>