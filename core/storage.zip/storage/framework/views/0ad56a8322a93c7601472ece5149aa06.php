<div class="coupon-content py-3">
    <?php if(auth()->guard()->check()): ?>
        <div class="coupon-content__form">
            <div class="applyCouponContainer">
                <div class="apply-coupon-code">
                    <input class="form-control form--control coupon" name="coupon_code" type="text" placeholder="<?php echo app('translator')->get('Enter Coupon Code'); ?>" value="<?php echo e(session('coupon')['code'] ?? ''); ?>">
                    <button id="applyCoupon" type="button" <?php if(session()->has('coupon')): echo 'disabled'; endif; ?>><?php echo app('translator')->get('Apply'); ?></button>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <div class="subtotal-wrapper gap-4">
        <span class="fs-16"><?php echo app('translator')->get('Subtotal :'); ?> </span>
        <strong>
            <?php echo e(gs('cur_sym')); ?><span class="cartSubtotal"><?php echo e(getAmount($subtotal)); ?></span>
        </strong>
    </div>
</div>

<?php
    // session()->put('coupon', ['code' => 'VISERMART', 'amount' => 30]);
?>

<div class="couponContent <?php if(!session()->has('coupon')): ?> d-none <?php endif; ?> mb-2">
    <div class="d-flex gap-3 justify-content-end align-items-center coupon-inner">
        <div>
            <button type="button" class="text-danger remove-coupon ps-0 removeCoupon">
                <i class="la la-times-circle"></i>
            </button>
            <small><?php echo app('translator')->get('Coupon'); ?>
                (<span class="couponCode fw-bold"><?php echo e(session('coupon')['code'] ?? ''); ?></span>)
                :
            </small>
        </div>
        <strong class="amount fs-16 d-block">
            - <?php echo e(gs('cur_sym')); ?><span id="couponAmount"><?php echo e(getAmount(session('coupon')['amount'] ?? 0)); ?></span>
        </strong>
    </div>
</div>

<div class="d-flex gap-3 justify-content-end cart-total-wrapper">
    <span><?php echo app('translator')->get('Total :'); ?></span>
    <strong class="amount d-block "><?php echo e(gs('cur_sym')); ?><span id="finalTotal"><?php echo e(getAmount($subtotal - (session('coupon')['amount'] ?? 0))); ?></span></strong>
</div>
<?php /**PATH C:\laragon\www\unisales\core\resources\views/templates/basic/partials/cart_bottom.blade.php ENDPATH**/ ?>