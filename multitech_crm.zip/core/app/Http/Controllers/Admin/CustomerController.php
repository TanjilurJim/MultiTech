<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Models\Customer;
use App\Http\Controllers\Controller;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\CustomerExport;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;


class CustomerController extends Controller
{
    //
    use AuthorizesRequests;

    public function __construct()
    {
        /*
         * One closure-based middleware for the whole controller:
         *   – maps the current action name to the correct policy ability
         *   – runs $this->authorize(...) for you
         */
        $this->middleware(function ($request, $next) {
            $method  = $request->route()->getActionMethod();   // e.g. index, show, update …
            $ability = $this->abilityMap()[$method] ?? null;   // e.g. viewAny, view, update …

            if ($ability) {
                // If the route contains {customer} → get the model instance
                $model = $request->route('customer');

                // viewAny receives only the class name
                $subject = $ability === 'viewAny' ? Customer::class : $model;

                $this->authorize($ability, $subject);
            }

            return $next($request);
        });
    }

    /**
     * Map controller method ➜ policy ability.
     * Same defaults Laravel uses internally.
     */
    protected function abilityMap(): array
    {
        return [
            'index'   => 'viewAny',
            'show'    => 'view',
            'edit'    => 'update',
            'update'  => 'update',
            'destroy' => 'delete',
            // add more if you create store/create etc.
        ];
    }


    public function index(Request $request)
    {
        $query = Customer::visibleTo(auth('admin')->user());

        // search/filter
        if ($term = $request->query('q')) {
            $query->where(function ($q) use ($term) {
                $q->where('name', 'like', "%$term%")
                    ->orWhere('company', 'like', "%$term%")
                    ->orWhere('contact_number', 'like', "%$term%");
            });
        }

        $pageTitle = 'Customer Database';

        $customers = $query->latest()->paginate(20);

        return view('admin.customers.index', compact('customers', 'term', 'pageTitle'));
    }


    public function edit(Customer $customer)
    {

        $pageTitle = 'Customer Information Edit';
        $bd        = getBangladeshLocationData();
        $postcodes = json_decode(
            file_get_contents(resource_path('data/bd-postcodes.json')),
            true
        )['postcodes'];

        return view('admin.customers.edit', compact('customer', 'bd', 'postcodes', 'pageTitle'));
    }

    public function show(Customer $customer)
    {
        $pageTitle = 'Customer Information';
        $bd = getBangladeshLocationData();
        $divName = collect($bd['divisions'])->pluck('name', 'id');
        $disName = collect($bd['districts'])->pluck('name', 'id');
        $upaName = collect($bd['upazilas'])->pluck('name', 'id');
        return view('admin.customers.show', compact('customer', 'divName', 'disName', 'upaName', 'pageTitle'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name'           => 'required|string',
            'company'        => 'nullable|string',
            'contact_number' => 'required|string',
            'email'          => 'nullable|email',
            'division_id'    => 'required|integer',
            'district_id'    => 'required|integer',
            // 'thana_id'       => 'required',
            'area_name' => 'required|string',
            'postcode'       => 'nullable|string',
            'remarks'        => 'nullable|string',
        ]);

        Customer::create($data);
        return back()->with('success', 'Customer added.');
    }

    public function update(Request $request, Customer $customer)
    {
        $data = $request->validate([
            'name'           => 'required|string',
            'company'        => 'nullable|string',
            'contact_number' => 'required|string',
            'email'          => 'nullable|email',
            'division_id'    => 'required|integer',
            'district_id'    => 'required|integer',
            // 'thana_id'       => 'required',
            'area_name' => 'required|string',
            'postcode'       => 'nullable|string',
            'remarks'        => 'nullable|string',
        ]);

        $customer->update($data);

        return redirect()->route('admin.customers.index')
            ->with('success', 'Customer updated.');
    }

    public function destroy(Customer $customer)
    {
        $customer->delete();
        return back()->with('success', 'Customer removed.');
    }

    public function export()
{
    $admin = auth('admin')->user();
    return Excel::download(new CustomerExport($admin), 'customers.xlsx');
}
}
