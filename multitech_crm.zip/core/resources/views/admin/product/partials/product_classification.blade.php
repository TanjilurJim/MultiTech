<div class="card has-select2">
    <div class="card-header">
        <h5 class="card-title mb-0">@lang('Product Classification')</h5>
    </div>
    <div class="card-body">

    </div>
</div>
