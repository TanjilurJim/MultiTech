@extends('admin.layouts.app')

@section('panel')
    {{-- flash message --}}
    <x-flash-toast />

    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <h4 class="mb-0 fw-semibold">
            <i class="las la-users me-1"></i> Admin Users
        </h4>

        <div class="d-flex gap-2 flex-wrap">
            {{-- SEARCH --}}
            <form method="GET" class="d-flex">
                <input type="text" name="q" value="{{ $search ?? '' }}" placeholder="Search name or email…"
                    class="form-control form-control-sm me-2">
                <button class="btn btn-sm btn-secondary">
                    <i class="las la-search"></i>
                </button>
            </form>

            {{-- ADD USER --}}
            @can('users.add')
                <a href="{{ route('admin.admin-users.create') }}" class="btn btn-sm btn-primary">
                    <i class="las la-plus-circle me-1"></i> Add User
                </a>
            @endcan
        </div>
    </div>


    <div class="card shadow-sm">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Roles</th>
                        {{-- <th>Perms</th> --}}
                        <th class="text-end" style="width:130px">Actions</th>
                    </tr>
                </thead>

                <tbody>
                    @forelse ($admins as $u)
                        <tr>
                            <td class="fw-semibold">{{ $u->name }}</td>
                            <td>{{ $u->email }}</td>

                            <td>
                                @forelse ($u->roles as $r)
                                    <span class="badge bg-info mb-1">{{ $r->name }}</span>
                                @empty —
                                @endforelse
                            </td>

                            {{-- <td>
                            @forelse ($u->permissions as $p)
                                <span class="badge bg-secondary mb-1">{{ $p->name }}</span>
                            @empty — @endforelse
                        </td> --}}

                            <td class="text-end">
                                @can('users.edit')
                                    <a href="{{ route('admin.admin-users.edit', $u) }}"
                                        class="btn btn-sm btn-outline-secondary">
                                        <i class="las la-pen"></i>
                                    </a>
                                @endcan

                                @can('users.delete')
                                    @if (!$u->hasRole('super-admin'))
                                        <form class="d-inline" action="{{ route('admin.admin-users.destroy', $u) }}"
                                            method="POST" onsubmit="return confirm('Delete user?');">
                                            @csrf @method('DELETE')
                                            <button class="btn btn-sm btn-outline-danger">
                                                <i class="las la-trash"></i>
                                            </button>
                                        </form>
                                    @endif
                                @endcan
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="text-center py-4">– No admin found –</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        {{-- pagination --}}
        @if ($admins->hasPages())
            <div class="card-footer py-2">
                {{ $admins->links() }}
            </div>
        @endif
    </div>
@endsection
